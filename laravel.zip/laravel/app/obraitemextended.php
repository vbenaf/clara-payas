<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obraitemextended extends Model
{
    //
}
