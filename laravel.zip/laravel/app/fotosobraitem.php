<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fotosobraitem extends Model
{
    //
}
