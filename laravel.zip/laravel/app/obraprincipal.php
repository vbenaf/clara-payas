<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obraprincipal extends Model
{
    protected $table = "obraprincipal";

    //get items from obra principal

    public function obres(){
        return $this->hasMany('App\obraitem','obraprincipal_id');
    }
}
