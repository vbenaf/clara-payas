<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obraitem extends Model
{
    protected $table = "obraitem";
}
