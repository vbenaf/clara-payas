<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CLARA PAYAS</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('../resources/css/app.css')); ?>">
</head>
<body>
    
    <header>
        <nav class="nav">
            <div class="brand"><a href="<?php echo e(url('/')); ?>" class="brand-img"><img src="<?php echo e(asset('../storage/app/images/logo.png')); ?>"></a>
                <div class="nav-lang">
                    <ul class="nav-land-ul">
                        <li class="nav-lang-item"><a href="#" class="nav-lang-link">CA</a></li>
                        <li class="nav-lang-item"><a href="#" class="nav-lang-link">CAST</a></li>
                        <li class="nav-lang-item"><a href="#" class="nav-lang-link">EN</a></li>
                    </ul>
                </div>
            </div>
            <div class="nav-items">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>">INICI</a></li>
                    <li><a href="<?php echo e(url('/obres')); ?>">TREBALLS</a></li>
                    <li><a href="#">BIO</a></li>
                    <li><a href="#">CV</a></li>
                    <li><a href="#">CONTACTE</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="main-image"></div>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
</body>
</html>

<style>
    .main-image::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('../storage/app/images/background.jpg') center no-repeat;
    background-size: cover;
    background-attachment: fixed;
    z-index:-1;
}
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/clara_payas_nou/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>