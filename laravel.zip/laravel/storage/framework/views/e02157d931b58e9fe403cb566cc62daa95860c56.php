<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $obres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <h1>
        <?php echo e($obra->titol); ?>

    </h1>
    <div class="grid">
        <?php $__currentLoopData = $obra->obres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            <?php echo e($obra_item->titol); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<style>
    .container{
        background-color: white;
        padding:0 3rem 0 3rem;
        padding:2rem;
        height:100%;
    }
    .grid{
        text-align: center;
        margin: 4rem 0 0 0;
        display:grid;
        grid-template-columns: repeat(auto-fit,minmax(25rem,1fr));
    }
    .item{
        margin: 2rem;
        border:2px solid black;
        padding:2rem;
    }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/clara_payas_nou/laravel/resources/views/obres.blade.php ENDPATH**/ ?>