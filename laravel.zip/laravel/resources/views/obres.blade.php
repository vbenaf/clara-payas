@extends('layouts.app')

@section('content')
<div class="container">
    @foreach ($obres as $obra)

    <h1>
        {{ $obra->titol }}
    </h1>
    <div class="grid">
        @foreach ($obra->obres as $obra_item)
        <div class="item">
            {{ $obra_item->titol }}
        </div>
        @endforeach
    </div>
    @endforeach
</div>
@endsection

<style>
    .container{
        background-color: white;
        padding:0 3rem 0 3rem;
        padding:2rem;
        height:100%;
    }
    .grid{
        text-align: center;
        margin: 4rem 0 0 0;
        display:grid;
        grid-template-columns: repeat(auto-fit,minmax(28rem,1fr));
    }
    .item{
        margin: 2rem;
        border:2px solid black;
        padding:2rem;
    }
</style>
